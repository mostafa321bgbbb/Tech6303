class Clustering:
    def __init__(self) -> None:
        ######################## clusterers to be implemented ####################################
        pass
    def Fit(self, estimator):
        estimator.fit(self.__train_x, self.__train_y)
        ######################## classifiers to be implemented ####################################
    def Predict(self, estimator):
        ########################To be implemented####################################
        pass